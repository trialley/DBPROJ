from django.apps import AppConfig


class HousesConfig(AppConfig):
    name = 'houses'
